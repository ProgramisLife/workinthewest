<link rel="stylesheet" href="{{ asset('assets/css/footer.css') }}" />
<footer class="text-light position-absolute bg-primary text-white">
    <p class="text-center">
        Copyright &copy; {{ date('Y') }} Fundacja Głos Młodych
    </p>
</footer>