@extends('layouts.app')

@section('content')
<h1>Juchu udało się.</h1>
@endsection